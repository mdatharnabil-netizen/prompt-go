# Prompt Go

Paste a video link (YouTube/Vimeo) or upload a photo, and Claude analyzes it deeply to produce a
detailed prompt you can use with any image generator to recreate that look.

## How it works
- **Photo upload**: the image is sent straight to Claude's vision API for analysis.
- **Video link**: full video download/analysis isn't possible for third-party platforms (it would
  violate their terms of service, and most don't expose raw video files via API). Instead, the
  app fetches the video's official thumbnail (via YouTube's thumbnail CDN or Vimeo's oEmbed API)
  and analyzes that frame. This is disclosed in the UI so it's never misleading to users.

## Local setup
```bash
npm install
cp .env.local.example .env.local
# edit .env.local and paste in your real Anthropic API key
npm run dev
```
Visit http://localhost:3000

## Get an Anthropic API key
1. Go to https://console.anthropic.com
2. Create an API key under Settings → API Keys
3. Put it in `.env.local` as `ANTHROPIC_API_KEY=sk-ant-...`

## Deploy: GitHub → Vercel
1. Push this folder to a new GitHub repo:
   ```bash
   git init
   git add .
   git commit -m "Prompt Go"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/prompt-go.git
   git push -u origin main
   ```
2. Go to https://vercel.com, click **New Project**, and import that GitHub repo.
3. In the Vercel project's **Settings → Environment Variables**, add:
   - `ANTHROPIC_API_KEY` = your key
4. Deploy. Vercel builds and hosts both the frontend and the `/api/analyze` serverless function
   automatically — no separate backend needed.

## Notes
- Your API key never reaches the browser — it's only used inside the serverless function.
- Claude API usage is billed per request on your Anthropic account — keep an eye on usage if the
  site gets public traffic.
- Image generation itself isn't included — this tool produces the *prompt text*, which you paste
  into whatever image generator you use (Midjourney, DALL·E, Stable Diffusion, etc.).
