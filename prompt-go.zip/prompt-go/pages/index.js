import { useState } from 'react';

export default function Home() {
  const [mode, setMode] = useState('photo'); // 'photo' | 'video'
  const [videoUrl, setVideoUrl] = useState('');
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [error, setError] = useState('');

  function handleFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setResult('');
    setError('');
  }

  async function fileToBase64(f) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(f);
    });
  }

  async function handleAnalyze() {
    setError('');
    setResult('');
    setLoading(true);
    try {
      let body;
      if (mode === 'photo') {
        if (!file) {
          setError('Upload a photo first.');
          setLoading(false);
          return;
        }
        const base64 = await fileToBase64(file);
        body = { type: 'photo', mediaType: file.type, imageBase64: base64 };
      } else {
        if (!videoUrl.trim()) {
          setError('Paste a video link first.');
          setLoading(false);
          return;
        }
        body = { type: 'video', url: videoUrl.trim() };
      }

      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Something went wrong.');
      setResult(data.prompt);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  function copyResult() {
    navigator.clipboard.writeText(result);
  }

  return (
    <div className="wrap">
      <div className="brand">
        <span className="dot" />
        <h1>Prompt Go</h1>
      </div>
      <div className="tagline">
        Paste a video link or upload a photo — get back a detailed prompt to recreate that look as an image.
      </div>

      <div className="tabs">
        <div
          className={`tab ${mode === 'photo' ? 'active' : ''}`}
          onClick={() => { setMode('photo'); setResult(''); setError(''); }}
        >
          Upload Photo
        </div>
        <div
          className={`tab ${mode === 'video' ? 'active' : ''}`}
          onClick={() => { setMode('video'); setResult(''); setError(''); }}
        >
          Video Link
        </div>
      </div>

      <div className="panel">
        {mode === 'photo' ? (
          <>
            <label className="dropzone">
              <input
                type="file"
                accept="image/*"
                onChange={handleFile}
                style={{ display: 'none' }}
              />
              {file ? file.name : 'Click to choose an image'}
            </label>
            {previewUrl && <img src={previewUrl} className="preview" alt="preview" />}
          </>
        ) : (
          <>
            <input
              type="text"
              placeholder="https://youtube.com/watch?v=... or any Vimeo/YouTube link"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
            />
            <div className="note">
              Note: full video content can't be downloaded or analyzed (platform restrictions).
              This analyzes the video's official thumbnail frame only — currently works for
              YouTube and Vimeo links.
            </div>
          </>
        )}

        <button className="primary" onClick={handleAnalyze} disabled={loading}>
          {loading ? 'Analyzing…' : 'Analyze & Generate Prompt'}
        </button>

        {error && <div className="error">{error}</div>}

        {result && (
          <div className="result">
            <button className="copy-btn" onClick={copyResult}>Copy</button>
            {result}
          </div>
        )}
      </div>

      <footer>Prompt Go — analysis powered by Claude</footer>
    </div>
  );
}
