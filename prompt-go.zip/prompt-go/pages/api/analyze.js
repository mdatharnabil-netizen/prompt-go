// Serverless function — runs on the server (Vercel), never exposes your API key to the browser.

const ANALYSIS_INSTRUCTIONS = `You are a visual analysis engine for "Prompt Go". Look closely at the
provided image and produce a single, richly detailed text-to-image prompt that would let an image
generation model recreate a photo with the same look, mood, and composition.

Cover, in flowing descriptive prose (not a list):
- Subject(s), pose, and framing
- Setting / background / environment
- Lighting (direction, quality, color temperature, time of day)
- Color palette and grading
- Camera/lens feel (focal length impression, depth of field, angle)
- Texture, material, and fine detail
- Overall mood and style (e.g. cinematic, editorial, analog film, hyperrealistic 3D, etc.)

Output ONLY the finished prompt text — no preamble, no headings, no markdown, no quotation marks
around it.`;

async function callClaude({ mediaType, imageBase64 }) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error('Server is missing ANTHROPIC_API_KEY. Add it in your Vercel project settings.');
  }

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 700,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: mediaType, data: imageBase64 },
            },
            { type: 'text', text: ANALYSIS_INSTRUCTIONS },
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Claude API error (${response.status}): ${text}`);
  }

  const data = await response.json();
  const textBlock = data.content?.find((b) => b.type === 'text');
  if (!textBlock) throw new Error('No text returned from the model.');
  return textBlock.text.trim();
}

function extractYouTubeId(url) {
  const m = url.match(/(?:youtu\.be\/|v=|\/embed\/|\/shorts\/)([a-zA-Z0-9_-]{11})/);
  return m ? m[1] : null;
}

async function getThumbnail(url) {
  const ytId = extractYouTubeId(url);
  if (ytId) {
    return { imageUrl: `https://img.youtube.com/vi/${ytId}/maxresdefault.jpg`, mediaType: 'image/jpeg' };
  }
  if (/vimeo\.com/.test(url)) {
    const oembedRes = await fetch(`https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`);
    if (!oembedRes.ok) throw new Error('Could not fetch Vimeo thumbnail for that link.');
    const data = await oembedRes.json();
    if (!data.thumbnail_url) throw new Error('No thumbnail available for that Vimeo link.');
    return { imageUrl: data.thumbnail_url, mediaType: 'image/jpeg' };
  }
  throw new Error(
    'Only YouTube and Vimeo links are supported right now (platform restrictions prevent downloading video from most other sites).'
  );
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  try {
    const { type } = req.body;

    if (type === 'photo') {
      const { mediaType, imageBase64 } = req.body;
      if (!imageBase64) return res.status(400).json({ error: 'No image provided.' });
      const prompt = await callClaude({ mediaType: mediaType || 'image/jpeg', imageBase64 });
      return res.status(200).json({ prompt });
    }

    if (type === 'video') {
      const { url } = req.body;
      if (!url) return res.status(400).json({ error: 'No video link provided.' });

      const { imageUrl, mediaType } = await getThumbnail(url);
      const imgRes = await fetch(imageUrl);
      if (!imgRes.ok) throw new Error('Could not download the thumbnail image.');
      const buffer = Buffer.from(await imgRes.arrayBuffer());
      const imageBase64 = buffer.toString('base64');

      const prompt = await callClaude({ mediaType, imageBase64 });
      return res.status(200).json({
        prompt: `${prompt}\n\n(Note: based on the video's thumbnail frame, not the full video.)`,
      });
    }

    return res.status(400).json({ error: 'Unknown request type.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message || 'Internal error.' });
  }
}
